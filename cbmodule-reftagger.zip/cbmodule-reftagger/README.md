Reftagger Module
=================

Author
-----------------
Mark Skelton/Computer Know How, LLC

Summary
-----------------
Enables Reftagger on your website to create hover tooltips for Scripture references on your website.

Install Instructions
-----------------
Download code and extract it to your ContentBox modules folder in the ContentBox module or install from the download manager.

Change Log
-----------------
* Version 1.0 - Initial Release
